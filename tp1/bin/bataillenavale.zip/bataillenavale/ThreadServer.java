package bataillenavale;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Arrays;

public class ThreadServer extends Thread {
	
	BufferedReader in_cl1, in_cl2;
	PrintWriter out_cl1, out_cl2;
	Plateau p_cl1 = new Plateau();
	Plateau p_cl2 = new Plateau();
	
	
	public ThreadServer(Socket cl_1,Socket cl_2) {
		try {
			in_cl1 = new BufferedReader(new InputStreamReader(cl_1.getInputStream()));
			out_cl1 = new PrintWriter(cl_1.getOutputStream(),true);
			
			in_cl2 = new BufferedReader(new InputStreamReader(cl_2 .getInputStream()));
			out_cl2 =new PrintWriter(cl_2.getOutputStream(),true);
					
			} catch(Exception e){}
}
	
	public void run() {
		
		try {
			
			while (true) {
				String mess_cl1 = in_cl1.readLine();
				String [] navire = mess_cl1.split(",");
				
				if(navire[0].equals("/config")) {
					
					String [] navire_string = Arrays.copyOfRange(navire, 1, navire.length); 
					int navire_int[] = new int [4];
					
					for(int j =0; j<4; j++) {
						navire_int[j] = Integer.parseInt(navire_string[j]);
//		        		System.out.println( treat[j] ) ;
		        	}
					p_cl1.set_navire(navire_int);
					
				}
				
				
				
			}
			
		} catch (Exception e) {
		}
		
		
		
	
	}
	
	
	

}
