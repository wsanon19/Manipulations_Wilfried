package bataillenavale;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client {
	
	public static Plateau mon_plateau = new Plateau() ;
	public static Plateau game_plateau = new Plateau();
	
	public static void main (String[] args) {

	    try{
	    	//Connexion a la session
	        Socket s =
	        new Socket("127.0.0.1", 1500);
	        BufferedReader in=
           		 new BufferedReader(new InputStreamReader(s.getInputStream()));
            PrintWriter out=new PrintWriter(s.getOutputStream(),true);
            
            //Parametrage des plateaux 
            System.out.println("Bienvenue dans la partie !");
            System.out.println("Placer vos bateaux");
            
            //Configuranton de son plateau
            String[] navire_tab = {"porte_avion(5)", "croiseur(5)", "contre_croiseur(3)", "sous_marin(3)", "torpilleur(2)"};
            Scanner lecture =  new Scanner(System.in);
            String coo ;     
            int[] treat = null;
            for (int i=0; i<6; i++){
            	System.out.println("Entrer les coordoones du 1er et du dernier point du " + navire_tab[i] + "" );
            	System.out.println("Separer les coordonne par une virgule (li,ci,lf,cf)" );
            	coo = lecture.nextLine();
            	
            	//Envoyer les donnes au serveur 
            	out.println("/config," + coo );
            	
            	//Configurer le plateau en local 
            	for(int j =0; j<5; j++) {
            		treat[j] = Integer.parseInt( coo.split(",")[j] );
            	}
            	mon_plateau.set_navire(treat);
            	
            	
            }
            
            //Envoyer les donnes au serveur 
            
            
            
            //Afficher les deux plateaux   
            mon_plateau.afficherPlateau();
            game_plateau.afficherPlateau();
            
            
            


            //Parametrage des plateaux 
            System.out.println("Bienvenue dans la partie !");
            System.out.println("Placer vos bateaux");
            
            
            Scanner entry = new Scanner(System.in);
            String mot = entry.nextLine();
            
            
	        out.println(mot);
	        
	        System.out.println(in.readLine());  
	        
	        s.close();
	        }catch(Exception e){
	        //Traitement d’erreur
	        }

}
	}
